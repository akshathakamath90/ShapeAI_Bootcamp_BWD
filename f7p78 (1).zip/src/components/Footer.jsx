import React from "react";
//import ReactDOM from "react-dom";
function Footer() {
  return (
    <footer>
      <h1> ShapeAI</h1>
    </footer>
  );
}
export default Footer;
