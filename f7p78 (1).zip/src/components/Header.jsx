import React from "react";
//import ReactDOM from "react-dom";
function Header() {
  return (
    <header>
      <h1 className="header"> ShapeAI</h1>
    </header>
  );
}
export default Header;
