import React from "react";
//import ReactDOM from "react-dom";
function Note() 
{
  return (
    <div className="note">
      <h1 className="h1">       
        Hi I made this project during the 7 Days Free Bootcamp
        
      The instructor during the session was Mr. Shaurya Sinha (Data Analyst Intern at Jio). I got to
learn a lot during these 7 days and it was an amazing experience learning with SHAPEAI.
</h1>
    </div> );
}
export default Note;
